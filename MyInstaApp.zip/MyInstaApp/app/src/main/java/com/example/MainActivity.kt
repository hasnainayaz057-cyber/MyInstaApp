package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.example.ui.screens.InstagramLoginScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                InstagramLoginScreen(
                    savedAccounts = emptyList(),
                    onLoginSuccess = { _, _, _ -> },
                    onSkipToGuest = {}
                )
            }
        }
    }
}
